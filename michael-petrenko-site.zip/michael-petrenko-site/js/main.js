/* ==========================================================================
   MICHAEL PETRENKO — INTERACTIONS
   --------------------------------------------------------------------------
   Plain JavaScript, no libraries. Everything here is progressive: if this
   file fails to load, the page still reads correctly and every link works.
   ========================================================================== */

(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ----------------------------------------------------------------------
     1. SCROLL REVEALS
     Elements with class "reveal" fade up once when they enter the viewport.
     ---------------------------------------------------------------------- */

  var revealables = document.querySelectorAll('.reveal');

  function revealAll() {
    for (var i = 0; i < revealables.length; i++) revealables[i].classList.add('is-in');
  }

  if (reduceMotion || !('IntersectionObserver' in window)) {
    revealAll();
  } else {
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-in');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

    revealables.forEach(function (el) { revealObserver.observe(el); });

    // Safety net: nothing may stay invisible, whatever happens above.
    window.setTimeout(revealAll, 3000);
  }

  /* ----------------------------------------------------------------------
     2. ONE-SHOT SECTION ANIMATIONS
     The IDEA -> BUILD -> COMMUNICATE rail and the MP logo draw-in.
     ---------------------------------------------------------------------- */

  function animateOnce(selector, className) {
    var el = document.querySelector(selector);
    if (!el) return;

    if (reduceMotion || !('IntersectionObserver' in window)) {
      el.classList.add(className);
      return;
    }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add(className);
          obs.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.2 });
    obs.observe(el);

    // Safety net: if the observer never fires (a very fast scroll, an odd
    // browser), play the animation anyway so nothing stays invisible.
    window.setTimeout(function () { el.classList.add(className); }, 4000);
  }

  animateOnce('#process', 'is-in');
  animateOnce('#mpLogo', 'is-in');

  /* ----------------------------------------------------------------------
     3. ELEVATOR PITCH — highlight key phrases line by line on scroll
     ---------------------------------------------------------------------- */

  var scriptLines = document.querySelectorAll('.script__line');

  if (scriptLines.length) {
    if (reduceMotion || !('IntersectionObserver' in window)) {
      scriptLines.forEach(function (line) { line.classList.add('is-lit'); });
    } else {
      var lineObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) entry.target.classList.add('is-lit');
        });
      }, { rootMargin: '-15% 0px -25% 0px', threshold: 0 });

      scriptLines.forEach(function (line) { lineObserver.observe(line); });
      window.setTimeout(function () {
        scriptLines.forEach(function (line) { line.classList.add('is-lit'); });
      }, 12000);
    }
  }

  /* ----------------------------------------------------------------------
     4. NAVIGATION — blur on scroll, active link, mobile menu
     ---------------------------------------------------------------------- */

  var nav = document.getElementById('nav');
  var navLinks = Array.prototype.slice.call(document.querySelectorAll('.nav__link'));
  var sections = navLinks
    .map(function (link) { return document.querySelector(link.getAttribute('href')); })
    .filter(Boolean);

  var heroPhoto = document.querySelector('[data-parallax]');
  var parallaxAmount = heroPhoto ? parseFloat(heroPhoto.getAttribute('data-parallax')) : 0;
  var ticking = false;

  function onScroll() {
    var y = window.pageYOffset || document.documentElement.scrollTop;

    // Translucent bar once the page has moved.
    if (nav) nav.classList.toggle('is-stuck', y > 24);

    // Active nav link = the last section whose top has passed the nav.
    var marker = y + 140;
    var activeIndex = 0;
    for (var i = 0; i < sections.length; i++) {
      if (sections[i].offsetTop <= marker) activeIndex = i;
    }
    // At the very bottom, always light the last item.
    if (window.innerHeight + y >= document.body.offsetHeight - 4) {
      activeIndex = sections.length - 1;
    }
    for (var j = 0; j < navLinks.length; j++) {
      navLinks[j].classList.toggle('is-active', j === activeIndex);
    }

    // Gentle hero parallax (desktop only, motion-safe).
    if (heroPhoto && !reduceMotion && window.innerWidth > 1000 && y < window.innerHeight * 1.2) {
      heroPhoto.style.transform = 'translate3d(0,' + (-y * parallaxAmount).toFixed(2) + 'px,0)';
    } else if (heroPhoto) {
      heroPhoto.style.transform = '';
    }

    ticking = false;
  }

  function requestScroll() {
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(onScroll);
    }
  }

  window.addEventListener('scroll', requestScroll, { passive: true });
  window.addEventListener('resize', requestScroll);
  onScroll();

  /* ---- Mobile menu ---- */

  var toggle = document.getElementById('navToggle');
  var mobile = document.getElementById('navMobile');

  function setMenu(open) {
    if (!toggle || !mobile) return;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    mobile.hidden = !open;
  }

  if (toggle && mobile) {
    toggle.addEventListener('click', function () {
      setMenu(toggle.getAttribute('aria-expanded') !== 'true');
    });
    mobile.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') setMenu(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') setMenu(false);
    });
    window.addEventListener('resize', function () {
      if (window.innerWidth > 820) setMenu(false);
    });
  }

  /* ----------------------------------------------------------------------
     5. SMOOTH SCROLL for browsers without CSS scroll-behavior
     ---------------------------------------------------------------------- */

  if (!('scrollBehavior' in document.documentElement.style) && !reduceMotion) {
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        var target = document.querySelector(link.getAttribute('href'));
        if (!target) return;
        e.preventDefault();
        window.scrollTo(0, target.offsetTop - 80);
      });
    });
  }

  /* ----------------------------------------------------------------------
     6. Footer year
     ---------------------------------------------------------------------- */

  var year = document.getElementById('year');
  if (year) year.textContent = String(new Date().getFullYear());

})();
