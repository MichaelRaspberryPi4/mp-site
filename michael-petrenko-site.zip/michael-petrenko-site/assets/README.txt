PUT YOUR MEDIA IN THIS FOLDER
=============================

michael.jpg          Your profile photo.
                     Portrait orientation, about 1000 x 1250 pixels.
                     Used in the hero section at the top of the page.

pitch.mp4            Your 30-45 second elevator pitch video.
                     Landscape 16:9, ideally 1920 x 1080.
                     Keep it under about 60 MB so it loads quickly.

pitch-poster.jpg     OPTIONAL. A still frame from your video, shown
                     before someone presses play. 1920 x 1080.

After adding the files, open index.html and follow the instructions in
the comment blocks marked "REPLACE #1" (photo) and "REPLACE #2" (video).
Full step-by-step instructions are in README.md in the folder above.
